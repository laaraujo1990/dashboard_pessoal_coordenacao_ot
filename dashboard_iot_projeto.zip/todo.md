# Projeto de Dashboard de Analista de Dados

## Fase 1: Planejamento e estruturação do dashboard
- [ ] Definir as métricas e KPIs chave para o dashboard.
- [ ] Esboçar a estrutura visual do dashboard (layout, tipos de gráficos).
- [ ] Identificar as tecnologias e ferramentas a serem utilizadas.

## Fase 2: Coleta e preparação de dados simulados
- [x] Gerar dados simulados para telemetria de dispositivos (MQTT, SNMP).
- [x] Gerar dados simulados para status de rede (VPN, conectividade).
- [x] Gerar dados simulados para indicadores operacionais (SCADA, comissionamento).
- [x] Estruturar os dados em um formato adequado para análise (CSV, JSON).

## Fase 3: Desenvolvimento do dashboard interativo
- [x] Configurar o ambiente de desenvolvimento.
- [x] Carregar e processar os dados simulados.
- [x] Desenvolver os componentes visuais do dashboard (gráficos, tabelas).
- [x] Implementar interatividade (filtros, drill-downs).
- [x] Garantir a responsividade do dashboard.

## Fase 4: Criação de documentação e apresentação
- [x] Escrever uma breve documentação sobre o dashboard (objetivo, funcionalidades, tecnologias).
- [x] Gerar imagens do dashboard para a apresentação.
- [x] Preparar um texto para o recrutador explicando o projeto.

## Fase 5: Entrega final ao usuário
- [ ] Empacotar todos os arquivos do projeto.
- [ ] Enviar o projeto e a documentação ao usuário.

