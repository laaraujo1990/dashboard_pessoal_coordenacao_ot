# Dashboard de Análise de Dados IoT/OT - Comgás

## Visão Geral

Este dashboard foi desenvolvido para demonstrar competências em análise de dados aplicadas ao contexto de infraestrutura crítica de telemetria IoT/OT, baseado na experiência profissional como Coordenador Técnico de IoT e OT na Comgás.

O projeto simula um ambiente real de monitoramento de milhares de dispositivos conectados distribuídos por longas distâncias, oferecendo insights acionáveis para tomada de decisões estratégicas em tempo real.

## Objetivos do Dashboard

### Objetivo Principal
Fornecer uma visão consolidada e interativa da saúde operacional da infraestrutura de telemetria, permitindo monitoramento proativo e análise de tendências para otimização da performance e confiabilidade dos sistemas.

### Objetivos Específicos
- **Monitoramento em Tempo Real**: Acompanhar o status de conectividade e performance de dispositivos IoT
- **Análise de Tendências**: Identificar padrões de comportamento e possíveis degradações de performance
- **Gestão de Alertas**: Centralizar e categorizar alertas críticos do sistema SCADA
- **Otimização Operacional**: Fornecer métricas para decisões de manutenção e expansão da rede
- **Análise de Comissionamento**: Avaliar eficiência dos processos de integração de novos equipamentos

## Arquitetura e Tecnologias Utilizadas

### Stack Tecnológico
- **Backend**: Python 3.11
- **Framework Web**: Dash (Plotly) - Para dashboards interativos e responsivos
- **Visualização de Dados**: Plotly Express e Plotly Graph Objects
- **Processamento de Dados**: Pandas e NumPy
- **Formato de Dados**: CSV para armazenamento e intercâmbio de dados

### Justificativa das Escolhas Tecnológicas
- **Dash**: Escolhido por sua capacidade de criar dashboards web interativos rapidamente, com componentes nativos para filtros e callbacks
- **Plotly**: Biblioteca robusta para visualizações interativas com suporte nativo a zoom, pan e drill-down
- **Python**: Linguagem versátil para análise de dados com ecossistema rico de bibliotecas especializadas

## Estrutura dos Dados

### Dados de IoT Cloud (Azure IoT Hub)
```
- timestamp: Data e hora da coleta
- device_id: Identificador único do dispositivo
- protocol: Protocolo de comunicação (MQTT/SNMP)
- status: Status de conectividade (online/offline)
- latency_ms: Latência de comunicação em milissegundos
- message_volume: Volume de mensagens transmitidas
- location: Localização geográfica (Norte/Sul/Leste/Oeste/Centro)
```

### Dados de SCADA (Elipse)
```
- timestamp: Data e hora da coleta
- asset_id: Identificador do ativo crítico
- availability: Status de disponibilidade (True/False)
- alert_type: Tipo de alerta gerado
- mttr_hours: Tempo médio para reparo em horas
- sensor_reading: Leituras dos sensores (pressão, temperatura, etc.)
```

### Dados de Comissionamento
```
- commissioning_date: Data do comissionamento
- device_id: Identificador do novo dispositivo
- success: Status de sucesso do comissionamento
- commissioning_time_hours: Tempo gasto no processo
- connectivity_type: Tipo de conectividade (Celular/Local/Satélite)
```

## Funcionalidades Implementadas

### 1. KPIs Principais (Cards de Resumo)
- **Dispositivos Conectados**: Total de dispositivos únicos ativos na rede
- **Disponibilidade (%)**: Percentual médio de disponibilidade dos ativos críticos
- **Latência Média (ms)**: Tempo médio de resposta da rede de comunicação
- **Taxa de Sucesso (%)**: Percentual de comissionamentos bem-sucedidos

### 2. Filtros Globais Interativos
- **Período**: Seletor de intervalo de datas para análise temporal
- **Localização**: Filtro multi-seleção por região geográfica

### 3. Seções Especializadas (Abas)

#### IoT Cloud (Azure)
- **Gráfico de Pizza**: Distribuição de status dos dispositivos (online/offline)
- **Gráfico de Linha**: Tendência de latência ao longo do tempo
- **Gráfico de Barras**: Volume de mensagens por protocolo de comunicação

#### SCADA (Elipse)
- **Gráfico de Linha**: Tendência de disponibilidade de ativos críticos
- **Gráfico de Barras**: Distribuição de tipos de alertas
- **Gráfico de Linha**: Leituras médias de sensores ao longo do tempo

#### Comissionamento
- **Gráfico de Pizza**: Distribuição por tipo de conectividade
- **Gráfico de Barras**: Taxa de sucesso mensal de comissionamentos
- **Gráfico de Barras**: Tempo médio de comissionamento por tipo de conectividade

#### Análise Geral
- **Gráfico de Dispersão**: Correlação entre volume de mensagens e latência
- **Mapa de Calor**: Atividade por localização e hora do dia
- **Tabela Resumo**: Métricas consolidadas por localização

### 4. Interatividade Avançada
- **Callbacks Dinâmicos**: Atualização automática de gráficos baseada nos filtros
- **Zoom e Pan**: Navegação detalhada nos gráficos temporais
- **Hover Information**: Detalhes contextuais ao passar o mouse sobre os dados
- **Responsividade**: Layout adaptável para diferentes tamanhos de tela

## Insights e Análises Disponíveis

### Análises Operacionais
1. **Identificação de Padrões de Falha**: Correlação entre tipos de conectividade e taxas de sucesso
2. **Otimização de Performance**: Análise da relação entre volume de dados e latência
3. **Planejamento de Manutenção**: Identificação de ativos com maior frequência de alertas
4. **Análise Geográfica**: Distribuição de performance por região

### Métricas de Negócio
1. **Eficiência Operacional**: Taxa de disponibilidade vs. tempo de reparo
2. **Qualidade de Serviço**: Monitoramento de SLAs de latência
3. **Crescimento da Rede**: Tendências de comissionamento de novos dispositivos
4. **Otimização de Recursos**: Identificação de gargalos de comunicação

## Casos de Uso Práticos

### Para Gestores Técnicos
- Monitoramento de KPIs operacionais em tempo real
- Identificação proativa de degradações de performance
- Planejamento de expansão baseado em dados históricos

### Para Analistas de Dados
- Análise de correlações entre diferentes métricas operacionais
- Identificação de padrões sazonais ou temporais
- Geração de relatórios automatizados para stakeholders

### Para Equipes de Campo
- Priorização de atividades de manutenção baseada em criticidade
- Análise de eficiência de diferentes tipos de conectividade
- Monitoramento de performance pós-comissionamento

## Escalabilidade e Extensibilidade

### Potenciais Expansões
1. **Integração com APIs Reais**: Conexão direta com Azure IoT Hub e sistemas SCADA
2. **Alertas Automatizados**: Sistema de notificações baseado em thresholds
3. **Machine Learning**: Modelos preditivos para antecipação de falhas
4. **Geolocalização**: Mapas interativos com posicionamento real dos dispositivos
5. **Relatórios Automatizados**: Geração de PDFs com análises periódicas

### Considerações de Performance
- **Otimização de Queries**: Implementação de cache para consultas frequentes
- **Processamento Assíncrono**: Para datasets muito grandes
- **Compressão de Dados**: Otimização do armazenamento de dados históricos

## Conclusão

Este dashboard demonstra competências essenciais para um Analista de Dados:

1. **Compreensão de Negócio**: Tradução de requisitos operacionais em métricas acionáveis
2. **Habilidades Técnicas**: Desenvolvimento de soluções interativas e escaláveis
3. **Visualização de Dados**: Criação de gráficos informativos e intuitivos
4. **Pensamento Analítico**: Identificação de correlações e padrões relevantes
5. **Experiência em IoT/OT**: Conhecimento específico do domínio de telemetria industrial

O projeto reflete a experiência real em coordenação de infraestruturas críticas de telemetria, demonstrando capacidade de transformar dados complexos em insights estratégicos para tomada de decisões.

